package com.moviebookingapp.dto;

import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@NoArgsConstructor
public class ValidateStatusDto {
	
	private boolean Status;

}
